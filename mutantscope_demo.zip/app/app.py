import streamlit as st
import pandas as pd, joblib, pathlib
from build_dataset import build_features
from train_model import train_and_save
from score_api import score_rows

ROOT = pathlib.Path(__file__).resolve().parents[1]
MODELS = ROOT / "models"
DATA = ROOT / "data"
MODELS.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)
MODEL_PATH = MODELS / "mutantscope.joblib"

st.set_page_config(page_title="MutantScope", layout="wide")
st.title("🧬 MutantScope — mutation impact demo")

tab1, tab2 = st.tabs(["Train from file", "Score trained model"])

with tab1:
    st.subheader("Upload mutations CSV and train")
    up = st.file_uploader("CSV with columns: protein, position, ref_aa, alt_aa, label", type=["csv"])
    if st.button("Use bundled sample"):
        up = open(DATA / "sample_mutations.csv", "rb")
    if up:
        df = pd.read_csv(up)
        colmap = {'protein':'protein','position':'position','ref_aa':'ref_aa','alt_aa':'alt_aa','label':'label'}
        Xy = build_features(df, colmap)
        if 'label' not in Xy.columns:
            st.error("No label column found after featurization.")
        else:
            acc = train_and_save(Xy, 'label', str(MODEL_PATH))
            st.success(f"Model trained and saved to {MODEL_PATH.name}. Holdout accuracy ~ {acc:.3f}")

with tab2:
    st.subheader("Score with saved model")
    if not MODEL_PATH.exists():
        st.info("Train a model first in the previous tab.")
    else:
        up2 = st.file_uploader("Feature table CSV (delta_hydro, delta_charge, is_conservative)", type=["csv"], key="sc")
        if st.button("Score sample (auto-build)"):
            df = pd.read_csv(DATA / "sample_mutations.csv")
            colmap = {'protein':'protein','position':'position','ref_aa':'ref_aa','alt_aa':'alt_aa','label':'label'}
            Xy = build_features(df, colmap)
            X = Xy.drop(columns=['label'])
            proba = score_rows(X)
            out = X.copy()
            if proba.shape[1] == 2:
                out['prob_up'] = proba[:,1]
            else:
                out[['prob_down','prob_neutral','prob_up']] = proba
            out.to_csv(ROOT / "scored_variants.csv", index=False)
            st.success("Wrote scored_variants.csv in project root.")
            st.dataframe(out.head())
        if up2:
            X = pd.read_csv(up2)
            proba = score_rows(X)
            out = X.copy()
            if proba.shape[1] == 2:
                out['prob_up'] = proba[:,1]
            else:
                out[['prob_down','prob_neutral','prob_up']] = proba
            st.dataframe(out.head())

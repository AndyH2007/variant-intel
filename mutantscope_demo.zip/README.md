# MutantScope Demo

Quick start:
1) python -m venv .venv
2) .venv\Scripts\Activate     (PowerShell: .\.venv\Scripts\Activate)
3) pip install -r requirements.txt
4) streamlit run app/app.py
